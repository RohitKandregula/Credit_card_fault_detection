# Credit_card_fault_detection
Using ML to classify the credit card as faulty or not
